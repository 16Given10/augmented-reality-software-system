@file:Suppress("UNUSED")
package com.example.cosc3001

/**
 * Legacy chat service placeholder removed per request to eliminate prior external provider code.
 * Safe to delete this file entirely once confirmed no references remain.
 */
