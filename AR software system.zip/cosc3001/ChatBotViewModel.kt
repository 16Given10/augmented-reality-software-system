package com.example.cosc3001

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Simple chat message representation for the in-app temporary chatbot overlay.
 */
data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String
) {
    enum class Role { User, Assistant, System }
}

class ChatBotViewModel(
    private val backend: ChatBackend,
    private val apiKeyPresent: Boolean
) : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _sending = MutableStateFlow(false)
    val sending: StateFlow<Boolean> = _sending.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private var counter = 0L

    init {
        if (!apiKeyPresent) {
            appendSystem("Chat service key missing. Responses are lightweight local hints only.")
        } else {
            appendSystem("Chat assistant ready. This overlay is temporary and not persisted.")
        }
    }

    private fun nextId() = ++counter

    private fun append(role: ChatMessage.Role, text: String) {
        _messages.value = _messages.value + ChatMessage(nextId(), role, text)
    }

    private fun appendSystem(text: String) = append(ChatMessage.Role.System, text)

    fun send(userInput: String) {
        val trimmed = userInput.trim()
        if (trimmed.isEmpty() || _sending.value) return
        append(ChatMessage.Role.User, trimmed)
        _sending.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                val reply = backend.sendMessage(trimmed)
                append(ChatMessage.Role.Assistant, reply)
            } catch (t: Throwable) {
                _error.value = t.message ?: t::class.simpleName ?: "error"
                append(ChatMessage.Role.System, "Error: ${_error.value}")
            } finally {
                _sending.value = false
            }
        }
    }

    fun clearError() { _error.value = null }
}
